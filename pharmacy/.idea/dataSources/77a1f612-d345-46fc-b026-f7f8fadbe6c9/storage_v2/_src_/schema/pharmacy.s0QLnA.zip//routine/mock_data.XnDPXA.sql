create
    definer = root@localhost function mock_data() returns int
BEGIN 
DECLARE num INT DEFAULT 200;
DECLARE i INT DEFAULT 0;
while i < num DO

INSERT INTO medicine (`name`)
VALUES(
CONCAT("测试药",i)
);
set i = i + 1;
end while;
RETURN i;
END;

