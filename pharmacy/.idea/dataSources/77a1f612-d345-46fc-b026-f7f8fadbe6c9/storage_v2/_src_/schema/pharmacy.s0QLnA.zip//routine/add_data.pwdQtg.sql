create
    definer = root@localhost function add_data() returns int
BEGIN 
DECLARE num INT DEFAULT 291;
DECLARE i INT DEFAULT 0;
while i < num DO

INSERT INTO medicine_synopsis (`gmt_create`)
VALUES(
CURRENT_TIMESTAMP
);
set i = i + 1;
end while;
RETURN i;
END;

